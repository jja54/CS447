Jack Anderson
jja54


Extra Credit:


Misc. Notes:
- ld output of Control doesn't do anything, just left it there for simplicity of
not having to shift all the wiring/edit the appearance of the subcircuit on the main
circuit.